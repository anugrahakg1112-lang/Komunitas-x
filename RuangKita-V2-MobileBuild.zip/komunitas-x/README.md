# RuangKita V2 — Community Web App

Aplikasi komunitas responsif dengan login/daftar simulasi, kanal, feed pesan, reaksi, pencarian kanal, animasi Rive, PWA, dan konfigurasi pembungkus Android Capacitor.

## Jalankan
1. Ekstrak ZIP dan buka folder `komunitas-x`.
2. Jalankan `index.html` melalui local server (misalnya Live Server atau `npm start`).
3. Koneksi internet diperlukan untuk memuat runtime Rive dan font eksternal.

## Build APK
Persyaratan: Node.js LTS, Android Studio, Android SDK.

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Jika folder `android` sudah ada, lewati `cap add android` dan jalankan `npx cap sync android`. Di Android Studio pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Batasan penting
- Login/registrasi masih simulasi frontend. Jangan gunakan kata sandi asli.
- Pesan dan kanal baru disimpan lokal pada browser/perangkat dan belum tersinkron antar pengguna.
- Pesan langsung, unggah lampiran, autentikasi aman, database, moderasi, dan chat realtime membutuhkan backend.
- Nama input/state machine Rive belum dipetakan, sehingga animasi diputar menggunakan artboard default.
- Jangan deploy publik sebagai layanan autentikasi sebelum backend dan keamanan diterapkan.
